package datalayer;

import java.sql.*;

public abstract class DBOperations {

    protected Connection con = null;

    protected void makeConnection() {
        try {
            if (con == null) {
           /*     Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                con = DriverManager.getConnection("jdbc:sqlserver://UnknownPC\\BLACKSERVER:49474;"
                        + "databaseName=WordPowerDB;userName=sa;password=negi123");
           */
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/wordpowerdb","root","root");
            }
        } catch (Exception ex) {
            System.out.print(ex);
        }
    }
}
