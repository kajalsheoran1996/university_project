package beans;

public class Usage {
     private int UsageId;
    private String Usage;
    
    public int getUsageId() {
        return UsageId;
    }

    public void setUsageId(int UsageId) {
        this.UsageId = UsageId;
    }

    public String getUsage() {
        return Usage;
    }

    public void setUsage(String Usage) {
        this.Usage = Usage;
    }  
}
